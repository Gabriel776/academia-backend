// simple placeholder backend
const express=require("express");
const app=express();
app.get("/",(req,res)=>res.send("Backend funcionando"));
app.listen(3000);